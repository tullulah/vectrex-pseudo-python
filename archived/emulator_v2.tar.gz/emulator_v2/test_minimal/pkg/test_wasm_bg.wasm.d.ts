/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_testclass_free: (a: number, b: number) => void;
export const testclass_new: () => number;
export const testclass_value: (a: number) => number;
export const testclass_set_value: (a: number, b: number) => void;
export const greet: (a: number, b: number) => void;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_start: () => void;
