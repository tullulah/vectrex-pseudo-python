/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_testwasm_free: (a: number, b: number) => void;
export const testwasm_new: () => number;
export const testwasm_value: (a: number) => number;
export const test_function: () => number;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_start: () => void;
