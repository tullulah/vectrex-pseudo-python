// Integration tests entry point
mod integration;
