// Branch opcode tests
// Auto-generated - one file per opcode

pub mod test_branch_extended_opcodes;
pub mod test_jsr_indexed;
pub mod test_lbra_lbsr;
