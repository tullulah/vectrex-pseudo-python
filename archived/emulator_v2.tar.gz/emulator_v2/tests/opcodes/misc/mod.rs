// Misc opcode tests
// Auto-generated - one file per opcode

pub mod test_add;
pub mod test_adda;
pub mod test_and;
pub mod test_andcc;
pub mod test_clra;
pub mod test_clrb;
pub mod test_coma;
pub mod test_dec;
pub mod test_deca;
pub mod test_eor;
pub mod test_inc;
pub mod test_inca;
pub mod test_jmp_modes;
pub mod test_nega;
pub mod test_nop;
pub mod test_nop_corrected;
pub mod test_nop_fixed;
pub mod test_ora;
pub mod test_orcc;
pub mod test_sub;
pub mod test_suba;
pub mod test_sync;
pub mod test_tfr_exg_correct;
pub mod test_tst;
pub mod test_tsta;
