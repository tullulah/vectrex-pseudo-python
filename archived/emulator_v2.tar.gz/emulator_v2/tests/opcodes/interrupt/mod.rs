// Interrupt opcode tests
// Auto-generated - one file per opcode

mod test_irq_system;
pub mod test_rti_swi_cwai;
mod test_swi_variants;
