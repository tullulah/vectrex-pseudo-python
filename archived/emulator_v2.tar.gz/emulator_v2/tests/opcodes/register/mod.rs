// Register operations tests
// Category: Operations that modify registers directly
// Examples: ABX, INC, DEC, CLR

mod test_abx;
