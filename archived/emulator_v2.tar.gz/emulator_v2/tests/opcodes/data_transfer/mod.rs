// Data_Transfer opcode tests
// Auto-generated - one file per opcode

pub mod test_lda;
pub mod test_ldb;
pub mod test_ldd;
pub mod test_ldu;
pub mod test_ldx;
pub mod test_leas;
pub mod test_leau;
pub mod test_leax;
pub mod test_leay;
pub mod test_sta;
pub mod test_stb;
pub mod test_stu;
