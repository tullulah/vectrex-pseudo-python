// Test file for B register arithmetic and logical operations

use std::cell::UnsafeCell;
use std::rc::Rc;
use vectrex_emulator_v2::core::Cpu6809;

const RAM_START: u16 = 0xC800;

use super::setup_cpu_with_ram;

#[test]
fn test_subb_all_addressing_modes() {
    // Test SUBB with immediate mode (0xC0)
    let (mut cpu, memory) = setup_cpu_with_ram();
    cpu.registers_mut().b = 0x80;

    // Setup instruction in RAM area
    cpu.memory_bus_mut().write(0xC800, 0xC0); // SUBB immediate opcode
    cpu.memory_bus_mut().write(0xC801, 0x01); // operand
    cpu.registers_mut().pc = 0xC800;

    cpu.execute_instruction(false, false).unwrap();
    assert_eq!(cpu.registers().b, 0x7F); // 0x80 - 0x01 = 0x7F
    assert_eq!(cpu.registers().cc.n, false);
    assert_eq!(cpu.registers().cc.z, false);
    assert_eq!(cpu.registers().cc.v, true); // Overflow: negative - positive = positive
    assert_eq!(cpu.registers().cc.c, false);

    // Test SUBB with borrow (negative result wrapping)
    let (mut cpu, memory) = setup_cpu_with_ram();
    cpu.registers_mut().b = 0x00;

    // Setup instruction in RAM area
    cpu.memory_bus_mut().write(0xC800, 0xC0); // SUBB immediate opcode
    cpu.memory_bus_mut().write(0xC801, 0x01); // operand
    cpu.registers_mut().pc = 0xC800;

    cpu.execute_instruction(false, false).unwrap();
    assert_eq!(cpu.registers().b, 0xFF); // 0x00 - 0x01 = 0xFF (borrow)
    assert_eq!(cpu.registers().cc.n, true);
    assert_eq!(cpu.registers().cc.z, false);
    assert_eq!(cpu.registers().cc.v, false);
    assert_eq!(cpu.registers().cc.c, true); // Carry flag set (borrow occurred)
}
