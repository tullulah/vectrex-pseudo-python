// Integration tests
// Note: The old integration_test.rs was just a wrapper for opcodes/
// Now opcodes tests are properly categorized in tests/opcodes/
mod test_integration_components;
