//! Stub: contenido migrado a `opcodes_all.rs` (módulo unified_audit).
#[test]
fn opcode_audit_unified_stub(){ assert!(true, "Ver opcodes_all.rs::unified_audit"); }
