//! Stub: cobertura migrada a `opcodes_all.rs` (módulo unified_coverage)
#[test]
fn opcode_coverage_unified_stub(){ assert!(true); }
