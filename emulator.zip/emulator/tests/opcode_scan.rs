//! Stub: escaneo migrado a `opcodes_all.rs` (módulo unified_scan)
#[test]
fn opcode_scan_unified_stub(){ assert!(true); }
