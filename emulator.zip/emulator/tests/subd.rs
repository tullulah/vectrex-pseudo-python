//! Stub: pruebas SUBD migradas a `opcodes_all.rs` (módulo unified_subd)
#[test]
fn subd_unified_stub(){ assert!(true); }
