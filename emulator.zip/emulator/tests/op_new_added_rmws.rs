//! Stub: RMW / añadidos migrados a `opcodes_all.rs` (módulo unified_rmw_added)
#[test]
fn op_new_added_rmws_unified_stub(){ assert!(true); }
