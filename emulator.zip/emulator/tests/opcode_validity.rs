//! Stub: tests de validez migrados a `opcodes_all.rs` (módulo unified_validity)
#[test]
fn opcode_validity_unified_stub(){ assert!(true); }
