/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
