/* M09PST:C */

/*
 * (C) Copyright 1989,1990
 * All Rights Reserved
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#include <stdio.h>
#include <setjmp.h>
#include "asm.h"
#include "m6809.h"

#define S_NO_FORCE_LEN  0
#define S_FORCE_LEN_5   1
#define S_FORCE_LEN_8   2
#define S_FORCE_LEN_16  3


struct  mne     mne[] = {

        /* machine */

        NULL,   ".setdp",       S_SDP,          0,      0, S_NO_FORCE_LEN,

        /* system */

        NULL,   "CON",          S_ATYP,         0,      A_CON, S_NO_FORCE_LEN,
        NULL,   "OVR",          S_ATYP,         0,      A_OVR, S_NO_FORCE_LEN,
        NULL,   "REL",          S_ATYP,         0,      A_REL, S_NO_FORCE_LEN,
        NULL,   "ABS",          S_ATYP,         0,  A_ABS|A_OVR, S_NO_FORCE_LEN,
        NULL,   "NOPAG",        S_ATYP,         0,      A_NOPAG, S_NO_FORCE_LEN,
        NULL,   "PAG",          S_ATYP,         0,      A_PAG, S_NO_FORCE_LEN,

        NULL,   ".byte",        S_BYTE,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".db",          S_BYTE,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".word",        S_WORD,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".dw",          S_WORD,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".ascii",       S_ASCII,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".asciz",       S_ASCIZ,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".blkb",        S_BLK,          0,      1, S_NO_FORCE_LEN,
        NULL,   ".ds",          S_BLK,          0,      1, S_NO_FORCE_LEN,
        NULL,   ".blkw",        S_BLK,          0,      2, S_NO_FORCE_LEN,
        NULL,   ".page",        S_PAGE,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".title",       S_TITLE,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".sbttl",       S_SBTL,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".globl",       S_GLOBL,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".area",        S_DAREA,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".even",        S_EVEN,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".odd",         S_ODD,          0,      0, S_NO_FORCE_LEN,
        NULL,   ".if",          S_IF,           0,      0, S_NO_FORCE_LEN,
        NULL,   ".else",        S_ELSE,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".endif",       S_ENDIF,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".include",     S_INCL,         0,      0, S_NO_FORCE_LEN,
        NULL,   ".radix",       S_RADIX,        0,      0, S_NO_FORCE_LEN,
        NULL,   ".org",         S_ORG,          0,      0, S_NO_FORCE_LEN,
        NULL,   ".module",      S_MODUL,        0,      0, S_NO_FORCE_LEN,

        /* 6800 Compatibility */

        NULL,   "ldaa",         S_ACC,          0,      0x86, S_NO_FORCE_LEN,
        NULL,   "ldab",         S_ACC,          0,      0xC6, S_NO_FORCE_LEN,
        NULL,   "oraa",         S_ACC,          0,      0x8A, S_NO_FORCE_LEN,
        NULL,   "orab",         S_ACC,          0,      0xCA, S_NO_FORCE_LEN,
        NULL,   "staa",         S_STR,          0,      0x87, S_NO_FORCE_LEN,
        NULL,   "stab",         S_STR,          0,      0xC7, S_NO_FORCE_LEN,

        /* if this is changed, change struct opdata mc6800[] */

        NULL,   "aba",          S_6800,         0,      0, S_NO_FORCE_LEN,
        NULL,   "cba",          S_6800,         0,      1, S_NO_FORCE_LEN,
        NULL,   "clc",          S_6800,         0,      2, S_NO_FORCE_LEN,
        NULL,   "cli",          S_6800,         0,      3, S_NO_FORCE_LEN,
        NULL,   "clv",          S_6800,         0,      4, S_NO_FORCE_LEN,
        NULL,   "des",          S_6800,         0,      5, S_NO_FORCE_LEN,
        NULL,   "dex",          S_6800,         0,      6, S_NO_FORCE_LEN,
        NULL,   "ins",          S_6800,         0,      7, S_NO_FORCE_LEN,
        NULL,   "inx",          S_6800,         0,      8, S_NO_FORCE_LEN,
        NULL,   "psha",         S_6800,         0,      9, S_NO_FORCE_LEN,
        NULL,   "pshb",         S_6800,         0,      10, S_NO_FORCE_LEN,
        NULL,   "pula",         S_6800,         0,      11, S_NO_FORCE_LEN,
        NULL,   "pulb",         S_6800,         0,      12, S_NO_FORCE_LEN,
        NULL,   "sba",          S_6800,         0,      13, S_NO_FORCE_LEN,
        NULL,   "sec",          S_6800,         0,      14, S_NO_FORCE_LEN,
        NULL,   "sei",          S_6800,         0,      15, S_NO_FORCE_LEN,
        NULL,   "sev",          S_6800,         0,      16, S_NO_FORCE_LEN,
        NULL,   "tab",          S_6800,         0,      17, S_NO_FORCE_LEN,
        NULL,   "tap",          S_6800,         0,      18, S_NO_FORCE_LEN,
        NULL,   "tba",          S_6800,         0,      19, S_NO_FORCE_LEN,
        NULL,   "tpa",          S_6800,         0,      20, S_NO_FORCE_LEN,
        NULL,   "tsx",          S_6800,         0,      21, S_NO_FORCE_LEN,
        NULL,   "txs",          S_6800,         0,      22, S_NO_FORCE_LEN,
        NULL,   "wai",          S_6800,         0,      23, S_NO_FORCE_LEN,

        /* 6809 */

        NULL,   "sty",          S_STR1,         0,      0x8F, S_NO_FORCE_LEN,
        NULL,   "sty_5",        S_STR1,         0,      0x8F, S_FORCE_LEN_5,
        NULL,   "sty_8",        S_STR1,         0,      0x8F, S_FORCE_LEN_8,
        NULL,   "sty_16",       S_STR1,         0,      0x8F, S_FORCE_LEN_16,

        NULL,   "sts",          S_STR1,         0,      0xCF, S_NO_FORCE_LEN,
        NULL,   "sts_5",        S_STR1,         0,      0xCF, S_FORCE_LEN_5,
        NULL,   "sts_8",        S_STR1,         0,      0xCF, S_FORCE_LEN_8,
        NULL,   "sts_16",       S_STR1,         0,      0xCF, S_FORCE_LEN_16,

        NULL,   "sta",          S_STR,          0,      0x87, S_NO_FORCE_LEN,
        NULL,   "sta_5",        S_STR,          0,      0x87, S_FORCE_LEN_5,
        NULL,   "sta_8",        S_STR,          0,      0x87, S_FORCE_LEN_8,
        NULL,   "sta_16",       S_STR,          0,      0x87, S_FORCE_LEN_16,

        NULL,   "stb",          S_STR,          0,      0xC7, S_NO_FORCE_LEN,
        NULL,   "stb_5",        S_STR,          0,      0xC7, S_FORCE_LEN_5,
        NULL,   "stb_8",        S_STR,          0,      0xC7, S_FORCE_LEN_8,
        NULL,   "stb_16",       S_STR,          0,      0xC7, S_FORCE_LEN_16,

        NULL,   "stx",          S_STR,          0,      0x8F, S_NO_FORCE_LEN,
        NULL,   "stx_5",        S_STR,          0,      0x8F, S_FORCE_LEN_5,
        NULL,   "stx_8",        S_STR,          0,      0x8F, S_FORCE_LEN_8,
        NULL,   "stx_16",       S_STR,          0,      0x8F, S_FORCE_LEN_16,

        NULL,   "stu",          S_STR,          0,      0xCF, S_NO_FORCE_LEN,
        NULL,   "stu_5",        S_STR,          0,      0xCF, S_FORCE_LEN_5,
        NULL,   "stu_8",        S_STR,          0,      0xCF, S_FORCE_LEN_8,
        NULL,   "stu_16",       S_STR,          0,      0xCF, S_FORCE_LEN_16,

        NULL,   "std",          S_STR,          0,      0xCD, S_NO_FORCE_LEN,
        NULL,   "std_5",        S_STR,          0,      0xCD, S_FORCE_LEN_5,
        NULL,   "std_8",        S_STR,          0,      0xCD, S_FORCE_LEN_8,
        NULL,   "std_16",       S_STR,          0,      0xCD, S_FORCE_LEN_16,

        NULL,   "jsr",          S_STR,          0,      0x8D, S_NO_FORCE_LEN,
        NULL,   "jsr_5",        S_STR,          0,      0x8D, S_FORCE_LEN_5,
        NULL,   "jsr_8",        S_STR,          0,      0x8D, S_FORCE_LEN_8,
        NULL,   "jsr_16",       S_STR,          0,      0x8D, S_FORCE_LEN_16,

        NULL,   "cmpu",         S_LR2,          0,      0x83, S_NO_FORCE_LEN,
        NULL,   "cmpu_5",       S_LR2,          0,      0x83, S_FORCE_LEN_5,
        NULL,   "cmpu_8",       S_LR2,          0,      0x83, S_FORCE_LEN_8,
        NULL,   "cmpu_16",      S_LR2,          0,      0x83, S_FORCE_LEN_16,

        NULL,   "cmps",         S_LR2,          0,      0x8C, S_NO_FORCE_LEN,
        NULL,   "cmps_5",       S_LR2,          0,      0x8C, S_FORCE_LEN_5,
        NULL,   "cmps_8",       S_LR2,          0,      0x8C, S_FORCE_LEN_8,
        NULL,   "cmps_16",      S_LR2,          0,      0x8C, S_FORCE_LEN_16,

        NULL,   "cmpd",         S_LR1,          0,      0x83, S_NO_FORCE_LEN,
        NULL,   "cmpd_5",       S_LR1,          0,      0x83, S_FORCE_LEN_5,
        NULL,   "cmpd_8",       S_LR1,          0,      0x83, S_FORCE_LEN_8,
        NULL,   "cmpd_16",      S_LR1,          0,      0x83, S_FORCE_LEN_16,

        NULL,   "cmpy",         S_LR1,          0,      0x8C, S_NO_FORCE_LEN,
        NULL,   "cmpy_5",       S_LR1,          0,      0x8C, S_FORCE_LEN_5,
        NULL,   "cmpy_8",       S_LR1,          0,      0x8C, S_FORCE_LEN_8,
        NULL,   "cmpy_16",      S_LR1,          0,      0x8C, S_FORCE_LEN_16,

        NULL,   "ldy",          S_LR1,          0,      0x8E, S_NO_FORCE_LEN,
        NULL,   "ldy_5",        S_LR1,          0,      0x8E, S_FORCE_LEN_5,
        NULL,   "ldy_8",        S_LR1,          0,      0x8E, S_FORCE_LEN_8,
        NULL,   "ldy_16",       S_LR1,          0,      0x8E, S_FORCE_LEN_16,

        NULL,   "lds",          S_LR1,          0,      0xCE, S_NO_FORCE_LEN,
        NULL,   "lds_5",        S_LR1,          0,      0xCE, S_FORCE_LEN_5,
        NULL,   "lds_8",        S_LR1,          0,      0xCE, S_FORCE_LEN_8,
        NULL,   "lds_16",       S_LR1,          0,      0xCE, S_FORCE_LEN_16,

        NULL,   "subd",         S_LR,           0,      0x83, S_NO_FORCE_LEN,
        NULL,   "addd",         S_LR,           0,      0xC3, S_NO_FORCE_LEN,
        NULL,   "cpx",          S_LR,           0,      0x8C, S_NO_FORCE_LEN,

        NULL,   "cmpx",         S_LR,           0,      0x8C, S_NO_FORCE_LEN,
        NULL,   "cmpx_5",       S_LR,           0,      0x8C, S_FORCE_LEN_5,
        NULL,   "cmpx_8",       S_LR,           0,      0x8C, S_FORCE_LEN_8,
        NULL,   "cmpx_16",      S_LR,           0,      0x8C, S_FORCE_LEN_16,

        NULL,   "ldd",          S_LR,           0,      0xCC, S_NO_FORCE_LEN,
        NULL,   "ldd_5",        S_LR,           0,      0xCC, S_FORCE_LEN_5,
        NULL,   "ldd_8",        S_LR,           0,      0xCC, S_FORCE_LEN_8,
        NULL,   "ldd_16",       S_LR,           0,      0xCC, S_FORCE_LEN_16,

        NULL,   "ldx",          S_LR,           0,      0x8E, S_NO_FORCE_LEN,
        NULL,   "ldx_5",        S_LR,           0,      0x8E, S_FORCE_LEN_5,
        NULL,   "ldx_8",        S_LR,           0,      0x8E, S_FORCE_LEN_8,
        NULL,   "ldx_16",       S_LR,           0,      0x8E, S_FORCE_LEN_16,

        NULL,   "ldu",          S_LR,           0,      0xCE, S_NO_FORCE_LEN,
        NULL,   "ldu_5",        S_LR,           0,      0xCE, S_FORCE_LEN_5,
        NULL,   "ldu_8",        S_LR,           0,      0xCE, S_FORCE_LEN_8,
        NULL,   "ldu_16",       S_LR,           0,      0xCE, S_FORCE_LEN_16,

        NULL,   "leax",         S_LEA,          0,      0x30, S_NO_FORCE_LEN,
        NULL,   "leax_5",       S_LEA,          0,      0x30, S_FORCE_LEN_5,
        NULL,   "leax_8",       S_LEA,          0,      0x30, S_FORCE_LEN_8,
        NULL,   "leax_16",      S_LEA,          0,      0x30, S_FORCE_LEN_16,

        NULL,   "leay",         S_LEA,          0,      0x31, S_NO_FORCE_LEN,
        NULL,   "leay_5",       S_LEA,          0,      0x31, S_FORCE_LEN_5,
        NULL,   "leay_8",       S_LEA,          0,      0x31, S_FORCE_LEN_8,
        NULL,   "leay_16",      S_LEA,          0,      0x31, S_FORCE_LEN_16,

        NULL,   "leas",         S_LEA,          0,      0x32, S_NO_FORCE_LEN,
        NULL,   "leas_5",       S_LEA,          0,      0x32, S_FORCE_LEN_5,
        NULL,   "leas_8",       S_LEA,          0,      0x32, S_FORCE_LEN_8,
        NULL,   "leas_16",      S_LEA,          0,      0x32, S_FORCE_LEN_16,

        NULL,   "leau",         S_LEA,          0,      0x33, S_NO_FORCE_LEN,
        NULL,   "leau_5",       S_LEA,          0,      0x33, S_FORCE_LEN_5,
        NULL,   "leau_8",       S_LEA,          0,      0x33, S_FORCE_LEN_8,
        NULL,   "leau_16",      S_LEA,          0,      0x33, S_FORCE_LEN_16,

        NULL,   "pshs",         S_PULS,         0,      0x34, S_NO_FORCE_LEN,
        NULL,   "puls",         S_PULS,         0,      0x35, S_NO_FORCE_LEN,
        NULL,   "pshu",         S_PULU,         0,      0x36, S_NO_FORCE_LEN,
        NULL,   "pulu",         S_PULU,         0,      0x37, S_NO_FORCE_LEN,

        NULL,   "exg",          S_EXG,          0,      0x1E, S_NO_FORCE_LEN,
        NULL,   "tfr",          S_EXG,          0,      0x1F, S_NO_FORCE_LEN,

        NULL,   "cwai",         S_CC,           0,      0x3C, S_NO_FORCE_LEN,
        NULL,   "orcc",         S_CC,           0,      0x1A, S_NO_FORCE_LEN,
        NULL,   "andcc",        S_CC,           0,      0x1C, S_NO_FORCE_LEN,

        NULL,   "swi3",         S_INH2,         0,      0x3F, S_NO_FORCE_LEN,
        NULL,   "swi2",         S_INH1,         0,      0x3F, S_NO_FORCE_LEN,
        NULL,   "swi1",         S_INH,          0,      0x3F, S_NO_FORCE_LEN,

        NULL,   "abx",          S_INH,          0,      0x3A, S_NO_FORCE_LEN,
        NULL,   "asla",         S_INH,          0,      0x48, S_NO_FORCE_LEN,
        NULL,   "aslb",         S_INH,          0,      0x58, S_NO_FORCE_LEN,
        NULL,   "asra",         S_INH,          0,      0x47, S_NO_FORCE_LEN,
        NULL,   "asrb",         S_INH,          0,      0x57, S_NO_FORCE_LEN,
        NULL,   "clra",         S_INH,          0,      0x4F, S_NO_FORCE_LEN,
        NULL,   "clrb",         S_INH,          0,      0x5F, S_NO_FORCE_LEN,
        NULL,   "coma",         S_INH,          0,      0x43, S_NO_FORCE_LEN,
        NULL,   "comb",         S_INH,          0,      0x53, S_NO_FORCE_LEN,
        NULL,   "daa",          S_INH,          0,      0x19, S_NO_FORCE_LEN,
        NULL,   "deca",         S_INH,          0,      0x4A, S_NO_FORCE_LEN,
        NULL,   "decb",         S_INH,          0,      0x5A, S_NO_FORCE_LEN,
        NULL,   "inca",         S_INH,          0,      0x4C, S_NO_FORCE_LEN,
        NULL,   "incb",         S_INH,          0,      0x5C, S_NO_FORCE_LEN,
        NULL,   "lsla",         S_INH,          0,      0x48, S_NO_FORCE_LEN,
        NULL,   "lslb",         S_INH,          0,      0x58, S_NO_FORCE_LEN,
        NULL,   "lsra",         S_INH,          0,      0x44, S_NO_FORCE_LEN,
        NULL,   "lsrb",         S_INH,          0,      0x54, S_NO_FORCE_LEN,
        NULL,   "mul",          S_INH,          0,      0x3D, S_NO_FORCE_LEN,
        NULL,   "nega",         S_INH,          0,      0x40, S_NO_FORCE_LEN,
        NULL,   "negb",         S_INH,          0,      0x50, S_NO_FORCE_LEN,
        NULL,   "nop",          S_INH,          0,      0x12, S_NO_FORCE_LEN,
        NULL,   "rola",         S_INH,          0,      0x49, S_NO_FORCE_LEN,
        NULL,   "rolb",         S_INH,          0,      0x59, S_NO_FORCE_LEN,
        NULL,   "rora",         S_INH,          0,      0x46, S_NO_FORCE_LEN,
        NULL,   "rorb",         S_INH,          0,      0x56, S_NO_FORCE_LEN,
        NULL,   "rti",          S_INH,          0,      0x3B, S_NO_FORCE_LEN,
        NULL,   "rts",          S_INH,          0,      0x39, S_NO_FORCE_LEN,
        NULL,   "sex",          S_INH,          0,      0x1D, S_NO_FORCE_LEN,
        NULL,   "swi",          S_INH,          0,      0x3F, S_NO_FORCE_LEN,
        NULL,   "sync",         S_INH,          0,      0x13, S_NO_FORCE_LEN,
        NULL,   "tsta",         S_INH,          0,      0x4D, S_NO_FORCE_LEN,
        NULL,   "tstb",         S_INH,          0,      0x5D, S_NO_FORCE_LEN,

        NULL,   "lbrn",         S_LBRA,         0,      0x21, S_NO_FORCE_LEN,
        NULL,   "lbhi",         S_LBRA,         0,      0x22, S_NO_FORCE_LEN,
        NULL,   "lbls",         S_LBRA,         0,      0x23, S_NO_FORCE_LEN,
        NULL,   "lblos",        S_LBRA,         0,      0x23, S_NO_FORCE_LEN,
        NULL,   "lbcc",         S_LBRA,         0,      0x24, S_NO_FORCE_LEN,
        NULL,   "lbhs",         S_LBRA,         0,      0x24, S_NO_FORCE_LEN,
        NULL,   "lbhis",        S_LBRA,         0,      0x24, S_NO_FORCE_LEN,
        NULL,   "lbcs",         S_LBRA,         0,      0x25, S_NO_FORCE_LEN,
        NULL,   "lblo",         S_LBRA,         0,      0x25, S_NO_FORCE_LEN,
        NULL,   "lbne",         S_LBRA,         0,      0x26, S_NO_FORCE_LEN,
        NULL,   "lbeq",         S_LBRA,         0,      0x27, S_NO_FORCE_LEN,
        NULL,   "lbvc",         S_LBRA,         0,      0x28, S_NO_FORCE_LEN,
        NULL,   "lbvs",         S_LBRA,         0,      0x29, S_NO_FORCE_LEN,
        NULL,   "lbpl",         S_LBRA,         0,      0x2A, S_NO_FORCE_LEN,
        NULL,   "lbmi",         S_LBRA,         0,      0x2B, S_NO_FORCE_LEN,
        NULL,   "lbge",         S_LBRA,         0,      0x2C, S_NO_FORCE_LEN,
        NULL,   "lblt",         S_LBRA,         0,      0x2D, S_NO_FORCE_LEN,
        NULL,   "lbgt",         S_LBRA,         0,      0x2E, S_NO_FORCE_LEN,
        NULL,   "lble",         S_LBRA,         0,      0x2F, S_NO_FORCE_LEN,

        NULL,   "lbra",         S_LBSR,         0,      0x16, S_NO_FORCE_LEN,
        NULL,   "lbsr",         S_LBSR,         0,      0x17, S_NO_FORCE_LEN,

        NULL,   "neg",          S_SOP,          0,      0x40, S_NO_FORCE_LEN,
        NULL,   "neg_5",        S_SOP,          0,      0x40, S_FORCE_LEN_5,
        NULL,   "neg_8",        S_SOP,          0,      0x40, S_FORCE_LEN_8,
        NULL,   "neg_16",       S_SOP,          0,      0x40, S_FORCE_LEN_16,

        NULL,   "com",          S_SOP,          0,      0x43, S_NO_FORCE_LEN,
        NULL,   "com_5",        S_SOP,          0,      0x43, S_FORCE_LEN_5,
        NULL,   "com_8",        S_SOP,          0,      0x43, S_FORCE_LEN_8,
        NULL,   "com_16",       S_SOP,          0,      0x43, S_FORCE_LEN_16,

        NULL,   "lsr",          S_SOP,          0,      0x44, S_NO_FORCE_LEN,
        NULL,   "lsr_5",        S_SOP,          0,      0x44, S_FORCE_LEN_5,
        NULL,   "lsr_8",        S_SOP,          0,      0x44, S_FORCE_LEN_8,
        NULL,   "lsr_16",       S_SOP,          0,      0x44, S_FORCE_LEN_16,

        NULL,   "ror",          S_SOP,          0,      0x46, S_NO_FORCE_LEN,
        NULL,   "ror_5",        S_SOP,          0,      0x46, S_FORCE_LEN_5,
        NULL,   "ror_8",        S_SOP,          0,      0x46, S_FORCE_LEN_8,
        NULL,   "ror_16",       S_SOP,          0,      0x46, S_FORCE_LEN_16,

        NULL,   "asr",          S_SOP,          0,      0x47, S_NO_FORCE_LEN,
        NULL,   "asr_5",        S_SOP,          0,      0x47, S_FORCE_LEN_5,
        NULL,   "asr_8",        S_SOP,          0,      0x47, S_FORCE_LEN_8,
        NULL,   "asr_16",       S_SOP,          0,      0x47, S_FORCE_LEN_16,

        NULL,   "asl",          S_SOP,          0,      0x48, S_NO_FORCE_LEN,
        NULL,   "asl_5",        S_SOP,          0,      0x48, S_FORCE_LEN_5,
        NULL,   "asl_8",        S_SOP,          0,      0x48, S_FORCE_LEN_8,
        NULL,   "asl_16",       S_SOP,          0,      0x48, S_FORCE_LEN_16,

        NULL,   "lsl",          S_SOP,          0,      0x48, S_NO_FORCE_LEN,
        NULL,   "lsl_5",        S_SOP,          0,      0x48, S_FORCE_LEN_5,
        NULL,   "lsl_8",        S_SOP,          0,      0x48, S_FORCE_LEN_8,
        NULL,   "lsl_16",       S_SOP,          0,      0x48, S_FORCE_LEN_16,

        NULL,   "rol",          S_SOP,          0,      0x49, S_NO_FORCE_LEN,
        NULL,   "rol_5",        S_SOP,          0,      0x49, S_FORCE_LEN_5,
        NULL,   "rol_8",        S_SOP,          0,      0x49, S_FORCE_LEN_8,
        NULL,   "rol_16",       S_SOP,          0,      0x49, S_FORCE_LEN_16,

        NULL,   "dec",          S_SOP,          0,      0x4A, S_NO_FORCE_LEN,
        NULL,   "dec_5",        S_SOP,          0,      0x4A, S_FORCE_LEN_5,
        NULL,   "dec_8",        S_SOP,          0,      0x4A, S_FORCE_LEN_8,
        NULL,   "dec_16",       S_SOP,          0,      0x4A, S_FORCE_LEN_16,

        NULL,   "inc",          S_SOP,          0,      0x4C, S_NO_FORCE_LEN,
        NULL,   "inc_5",        S_SOP,          0,      0x4C, S_FORCE_LEN_5,
        NULL,   "inc_8",        S_SOP,          0,      0x4C, S_FORCE_LEN_8,
        NULL,   "inc_16",       S_SOP,          0,      0x4C, S_FORCE_LEN_16,

        NULL,   "tst",          S_SOP,          0,      0x4D, S_NO_FORCE_LEN,
        NULL,   "tst_5",        S_SOP,          0,      0x4D, S_FORCE_LEN_5,
        NULL,   "tst_8",        S_SOP,          0,      0x4D, S_FORCE_LEN_8,
        NULL,   "tst_16",       S_SOP,          0,      0x4D, S_FORCE_LEN_16,

        NULL,   "clr",          S_SOP,          0,      0x4F, S_NO_FORCE_LEN,
        NULL,   "clr_5",        S_SOP,          0,      0x4F, S_FORCE_LEN_5,
        NULL,   "clr_8",        S_SOP,          0,      0x4F, S_FORCE_LEN_8,
        NULL,   "clr_16",       S_SOP,          0,      0x4F, S_FORCE_LEN_16,

        NULL,   "jmp",          S_SOP,          0,      0x4E, S_NO_FORCE_LEN,
        NULL,   "jmp_5",        S_SOP,          0,      0x4E, S_FORCE_LEN_5,
        NULL,   "jmp_8",        S_SOP,          0,      0x4E, S_FORCE_LEN_8,
        NULL,   "jmp_16",       S_SOP,          0,      0x4E, S_FORCE_LEN_16,

        NULL,   "suba",         S_ACC,          0,      0x80, S_NO_FORCE_LEN,
        NULL,   "subb",         S_ACC,          0,      0xC0, S_NO_FORCE_LEN,
        NULL,   "cmpa",         S_ACC,          0,      0x81, S_NO_FORCE_LEN,
        NULL,   "cmpb",         S_ACC,          0,      0xC1, S_NO_FORCE_LEN,
        NULL,   "sbca",         S_ACC,          0,      0x82, S_NO_FORCE_LEN,
        NULL,   "sbcb",         S_ACC,          0,      0xC2, S_NO_FORCE_LEN,
        NULL,   "anda",         S_ACC,          0,      0x84, S_NO_FORCE_LEN,
        NULL,   "andb",         S_ACC,          0,      0xC4, S_NO_FORCE_LEN,
        NULL,   "bita",         S_ACC,          0,      0x85, S_NO_FORCE_LEN,
        NULL,   "bitb",         S_ACC,          0,      0xC5, S_NO_FORCE_LEN,
        NULL,   "eora",         S_ACC,          0,      0x88, S_NO_FORCE_LEN,
        NULL,   "eorb",         S_ACC,          0,      0xC8, S_NO_FORCE_LEN,
        NULL,   "adca",         S_ACC,          0,      0x89, S_NO_FORCE_LEN,
        NULL,   "adcb",         S_ACC,          0,      0xC9, S_NO_FORCE_LEN,
        NULL,   "adda",         S_ACC,          0,      0x8B, S_NO_FORCE_LEN,
        NULL,   "addb",         S_ACC,          0,      0xCB, S_NO_FORCE_LEN,
        NULL,   "lda",          S_ACC,          0,      0x86, S_NO_FORCE_LEN,
        NULL,   "ldb",          S_ACC,          0,      0xC6, S_NO_FORCE_LEN,
        NULL,   "ora",          S_ACC,          0,      0x8A, S_NO_FORCE_LEN,
        NULL,   "orb",          S_ACC,          0,      0xCA, S_NO_FORCE_LEN,

        NULL,   "suba_5",       S_ACC,          0,      0x80, S_FORCE_LEN_5,
        NULL,   "subb_5",       S_ACC,          0,      0xC0, S_FORCE_LEN_5,
        NULL,   "cmpa_5",       S_ACC,          0,      0x81, S_FORCE_LEN_5,
        NULL,   "cmpb_5",       S_ACC,          0,      0xC1, S_FORCE_LEN_5,
        NULL,   "sbca_5",       S_ACC,          0,      0x82, S_FORCE_LEN_5,
        NULL,   "sbcb_5",       S_ACC,          0,      0xC2, S_FORCE_LEN_5,
        NULL,   "anda_5",       S_ACC,          0,      0x84, S_FORCE_LEN_5,
        NULL,   "andb_5",       S_ACC,          0,      0xC4, S_FORCE_LEN_5,
        NULL,   "bita_5",       S_ACC,          0,      0x85, S_FORCE_LEN_5,
        NULL,   "bitb_5",       S_ACC,          0,      0xC5, S_FORCE_LEN_5,
        NULL,   "eora_5",       S_ACC,          0,      0x88, S_FORCE_LEN_5,
        NULL,   "eorb_5",       S_ACC,          0,      0xC8, S_FORCE_LEN_5,
        NULL,   "adca_5",       S_ACC,          0,      0x89, S_FORCE_LEN_5,
        NULL,   "adcb_5",       S_ACC,          0,      0xC9, S_FORCE_LEN_5,
        NULL,   "adda_5",       S_ACC,          0,      0x8B, S_FORCE_LEN_5,
        NULL,   "addb_5",       S_ACC,          0,      0xCB, S_FORCE_LEN_5,
        NULL,   "lda_5",        S_ACC,          0,      0x86, S_FORCE_LEN_5,
        NULL,   "ldb_5",        S_ACC,          0,      0xC6, S_FORCE_LEN_5,
        NULL,   "ora_5",        S_ACC,          0,      0x8A, S_FORCE_LEN_5,
        NULL,   "orb_5",        S_ACC,          0,      0xCA, S_FORCE_LEN_5,

        NULL,   "suba_8",       S_ACC,          0,      0x80, S_FORCE_LEN_8,
        NULL,   "subb_8",       S_ACC,          0,      0xC0, S_FORCE_LEN_8,
        NULL,   "cmpa_8",       S_ACC,          0,      0x81, S_FORCE_LEN_8,
        NULL,   "cmpb_8",       S_ACC,          0,      0xC1, S_FORCE_LEN_8,
        NULL,   "sbca_8",       S_ACC,          0,      0x82, S_FORCE_LEN_8,
        NULL,   "sbcb_8",       S_ACC,          0,      0xC2, S_FORCE_LEN_8,
        NULL,   "anda_8",       S_ACC,          0,      0x84, S_FORCE_LEN_8,
        NULL,   "andb_8",       S_ACC,          0,      0xC4, S_FORCE_LEN_8,
        NULL,   "bita_8",       S_ACC,          0,      0x85, S_FORCE_LEN_8,
        NULL,   "bitb_8",       S_ACC,          0,      0xC5, S_FORCE_LEN_8,
        NULL,   "eora_8",       S_ACC,          0,      0x88, S_FORCE_LEN_8,
        NULL,   "eorb_8",       S_ACC,          0,      0xC8, S_FORCE_LEN_8,
        NULL,   "adca_8",       S_ACC,          0,      0x89, S_FORCE_LEN_8,
        NULL,   "adcb_8",       S_ACC,          0,      0xC9, S_FORCE_LEN_8,
        NULL,   "adda_8",       S_ACC,          0,      0x8B, S_FORCE_LEN_8,
        NULL,   "addb_8",       S_ACC,          0,      0xCB, S_FORCE_LEN_8,
        NULL,   "lda_8",        S_ACC,          0,      0x86, S_FORCE_LEN_8,
        NULL,   "ldb_8",        S_ACC,          0,      0xC6, S_FORCE_LEN_8,
        NULL,   "ora_8",        S_ACC,          0,      0x8A, S_FORCE_LEN_8,
        NULL,   "orb_8",        S_ACC,          0,      0xCA, S_FORCE_LEN_8,

        NULL,   "suba_16",      S_ACC,          0,      0x80, S_FORCE_LEN_16,
        NULL,   "subb_16",      S_ACC,          0,      0xC0, S_FORCE_LEN_16,
        NULL,   "cmpa_16",      S_ACC,          0,      0x81, S_FORCE_LEN_16,
        NULL,   "cmpb_16",      S_ACC,          0,      0xC1, S_FORCE_LEN_16,
        NULL,   "sbca_16",      S_ACC,          0,      0x82, S_FORCE_LEN_16,
        NULL,   "sbcb_16",      S_ACC,          0,      0xC2, S_FORCE_LEN_16,
        NULL,   "anda_16",      S_ACC,          0,      0x84, S_FORCE_LEN_16,
        NULL,   "andb_16",      S_ACC,          0,      0xC4, S_FORCE_LEN_16,
        NULL,   "bita_16",      S_ACC,          0,      0x85, S_FORCE_LEN_16,
        NULL,   "bitb_16",      S_ACC,          0,      0xC5, S_FORCE_LEN_16,
        NULL,   "eora_16",      S_ACC,          0,      0x88, S_FORCE_LEN_16,
        NULL,   "eorb_16",      S_ACC,          0,      0xC8, S_FORCE_LEN_16,
        NULL,   "adca_16",      S_ACC,          0,      0x89, S_FORCE_LEN_16,
        NULL,   "adcb_16",      S_ACC,          0,      0xC9, S_FORCE_LEN_16,
        NULL,   "adda_16",      S_ACC,          0,      0x8B, S_FORCE_LEN_16,
        NULL,   "addb_16",      S_ACC,          0,      0xCB, S_FORCE_LEN_16,
        NULL,   "lda_16",       S_ACC,          0,      0x86, S_FORCE_LEN_16,
        NULL,   "ldb_16",       S_ACC,          0,      0xC6, S_FORCE_LEN_16,
        NULL,   "ora_16",       S_ACC,          0,      0x8A, S_FORCE_LEN_16,
        NULL,   "orb_16",       S_ACC,          0,      0xCA, S_FORCE_LEN_16,

        NULL,   "bra",          S_BRA,          0,      0x20, S_NO_FORCE_LEN,
        NULL,   "brn",          S_BRA,          0,      0x21, S_NO_FORCE_LEN,
        NULL,   "bhi",          S_BRA,          0,      0x22, S_NO_FORCE_LEN,
        NULL,   "bls",          S_BRA,          0,      0x23, S_NO_FORCE_LEN,
        NULL,   "blos",         S_BRA,          0,      0x23, S_NO_FORCE_LEN,
        NULL,   "bcc",          S_BRA,          0,      0x24, S_NO_FORCE_LEN,
        NULL,   "bhs",          S_BRA,          0,      0x24, S_NO_FORCE_LEN,
        NULL,   "bhis",         S_BRA,          0,      0x24, S_NO_FORCE_LEN,
        NULL,   "bcs",          S_BRA,          0,      0x25, S_NO_FORCE_LEN,
        NULL,   "blo",          S_BRA,          0,      0x25, S_NO_FORCE_LEN,
        NULL,   "bne",          S_BRA,          0,      0x26, S_NO_FORCE_LEN,
        NULL,   "beq",          S_BRA,          0,      0x27, S_NO_FORCE_LEN,
        NULL,   "bvc",          S_BRA,          0,      0x28, S_NO_FORCE_LEN,
        NULL,   "bvs",          S_BRA,          0,      0x29, S_NO_FORCE_LEN,
        NULL,   "bpl",          S_BRA,          0,      0x2A, S_NO_FORCE_LEN,
        NULL,   "bmi",          S_BRA,          0,      0x2B, S_NO_FORCE_LEN,
        NULL,   "bge",          S_BRA,          0,      0x2C, S_NO_FORCE_LEN,
        NULL,   "blt",          S_BRA,          0,      0x2D, S_NO_FORCE_LEN,
        NULL,   "bgt",          S_BRA,          0,      0x2E, S_NO_FORCE_LEN,
        NULL,   "ble",          S_BRA,          0,      0x2F, S_NO_FORCE_LEN,
        NULL,   "bsr",          S_BRA,          S_END,  0x8D, S_NO_FORCE_LEN
};

struct opdata mc6800[] = {

        0x34, 0x04,     /*      pshs    b       ;aba    */
        0xab, 0xe0,     /*      adda    ,s+     */

        0x34, 0x04,     /*      pshs    b       ;cba    */
        0xa1, 0xe0,     /*      cmpa    ,s+     */

        0x1c, 0xfe,     /*      andcc   #0xFE   ;clc    */
        0x00, 0x00,

        0x1c, 0xef,     /*      andcc   #0xEF   ;cli    */
        0x00, 0x00,

        0x1c, 0xfd,     /*      andcc   #0xFD   ;clv    */
        0x00, 0x00,

        0x32, 0x7f,     /*      leas    -1,s    ;des    */
        0x00, 0x00,

        0x30, 0x1f,     /*      leax    -1,x    ;dex    */
        0x00, 0x00,

        0x32, 0x61,     /*      leas    1,s     ;ins    */
        0x00, 0x00,

        0x30, 0x01,     /*      leax    1,x     ;inx    */
        0x00, 0x00,

        0x34, 0x02,     /*      pshs    a       ;psha   */
        0x00, 0x00,

        0x34, 0x04,     /*      pshs    b       ;pshb   */
        0x00, 0x00,

        0x35, 0x02,     /*      puls    a       ;pula   */
        0x00, 0x00,

        0x35, 0x04,     /*      puls    b       ;pulb   */
        0x00, 0x00,

        0x34, 0x04,     /*      pshs    b       ;sba    */
        0xa0, 0xe0,     /*      suba    ,s+     */

        0x1a, 0x01,     /*      orcc    #0x01   ;sec    */
        0x00, 0x00,

        0x1a, 0x10,     /*      orcc    #0x10   ;sei    */
        0x00, 0x00,

        0x1a, 0x02,     /*      orcc    #0x02   ;sev    */
        0x00, 0x00,

        0x1f, 0x89,     /*      tfr     a,b     ;tab    */
        0x4d, 0x00,     /*      tsta    */

        0x1f, 0x8a,     /*      tfr     a,cc    ;tap    */
        0x00, 0x00,

        0x1f, 0x98,     /*      tfr     b,a     ;tba    */
        0x5d, 0x00,     /*      tstb    */

        0x1f, 0xa8,     /*      tfr     cc,a    ;tpa    */
        0x00, 0x00,

        0x1f, 0x41,     /*      tfr     s,x     ;tsx    */
        0x00, 0x00,

        0x1f, 0x14,     /*      tfr     x,s     ;txs    */
        0x00, 0x00,

        0x3c, 0xff,     /*      cwai    #0xFF   ;wai    */
        0x00, 0x00
};
